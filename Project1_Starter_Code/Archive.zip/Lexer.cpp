#include "Lexer.h"
#include "ColonAutomaton.h"
#include "ColonDashAutomaton.h"
#include "CommaAutomaton.h"
#include "PeriodAutomaton.h"
#include "Q_MarkAutomaton.h"
#include "Left_ParenAutomaton.h"
#include "Right_ParenAutomaton.h"
#include "MultiplyAutomaton.h"
#include "AddAutomaton.h"
#include "SchemesAutomaton.h"
#include "Facts.h"
#include "RulesAutomaton.h"
#include "QueriesAutomaton.h"
#include "CommentAutomata.h"
#include "IDAutomaton.h"
#include "StringAutomaton.h"
#include "Automaton.h"
#include <iostream>
#include <cctype>

Lexer::Lexer() {
    CreateAutomata();
}

Lexer::~Lexer() {
    // TODO: need to clean up the memory in `automata` and `tokens`
    // Don't forget you still got to look at the newLines
}

void Lexer::CreateAutomata() {
    automata.push_back(new CommaAutomaton());
    automata.push_back(new CommentAutomata());
    automata.push_back(new PeriodAutomaton());
    automata.push_back(new Q_MarkAutomaton());
    automata.push_back(new Left_ParenAutomaton());
    automata.push_back(new Right_ParenAutomaton());
    automata.push_back(new ColonAutomaton());
    automata.push_back(new ColonDashAutomaton());
    automata.push_back(new MultiplyAutomaton());
    automata.push_back(new AddAutomaton());
    automata.push_back(new SchemesAutomaton());
    automata.push_back(new FactsAutomaton());
    automata.push_back(new RulesAutomaton());
    automata.push_back(new QueriesAutomaton());
    automata.push_back(new StringAutomaton());
    automata.push_back(new IDAutomaton());


}

void Lexer::Run(std::string& input) {
    int lineNumber = 1;

    while (input.size() > 0) {
        int maxRead = 0;
        Automaton *maxAutonama = automata.at(0);


        /* Here is the "Parallel" part of the algorithm
        //   Each automaton runs with the same input
        foreach automaton in automata {
                inputRead = automaton.Start(input)
                if (inputRead > maxRead) {
                    set maxRead to inputRead
                    set maxAutomaton to automaton
                }
        }
        */ //pseudo code for parallel algorithm
        /*while(isspace(input[0])){
            if(input[0] == '\n'){
                ++lineNumber;
                input = input.substr(1);
            }
            input.erase(0,1);
        }*/


        for (int i = 0; i < (int)automata.size(); ++i) {
            while (input.substr(0, 1) == "\n") {
                ++lineNumber;
                input = input.substr(1);} // Finds and erases newlines and increments LineNumber
            //if (isspace(input[0])){
                for (int i = 0; i < (int)input.size(); ++i){
                if (isspace(input[0]) && input[0] != '\n') {
                    input.erase(0, 1);}} // Finds and erases spaces
            int inputRead = automata.at(i)->Start(input);
                if (inputRead > maxRead) {
                    maxRead = inputRead;
                    maxAutonama = automata.at(i);
                }
            }

            /*if maxRead > 0 {
                set newToken to maxAutomaton.CreateToken(...)
                increment lineNumber by maxAutomaton.NewLinesRead()
                add newToken to collection of all tokens
            }*/ // pseudo code for if portion of max function
            if (maxRead > 0 && !isdigit(input[0])) {
                Token *newToken = maxAutonama->CreateToken(input, lineNumber);
                lineNumber += maxAutonama->NewLinesRead();
                newToken->ToString(maxRead);
                tokens.push_back(newToken);
            }

                /*else {
                    set maxRead to 1
                    set newToken to a  new undefined Token
                            (with first character of input)
                    add newToken to collection of all tokens
                }*/ // pseudo code for else portion of max function
            else if (input.size() > 0){
                maxRead = 1;
                Token *newToken;
                newToken = new Token(TokenType::UNDEFINED, input.substr(0, 1), lineNumber);
                newToken->ToString(1); // 1 because pseudo-code to make the length of the string one
                tokens.push_back(newToken);
            }

            input.erase(0, maxRead);
        }

        Token* EOFToken = new Token(TokenType::ENDOFFILE, "", lineNumber);
        tokens.push_back(EOFToken);
        EOFToken->ToString(1);
        std::cout << "Total Tokens = " << tokens.size();
        /*

        set lineNumber to 1
        // While there are more characters to tokenize
        loop while input.size() > 0 {
            set maxRead to 0
            set maxAutomaton to the first automaton in automata

            // TODO: you need to handle whitespace in between tokens



            // No automaton accepted input
            // Create single character undefined token

            // Update `input` by removing characters read to create Token
            remove maxRead characters from input
        }
        add end of file token to all tokens
        */
    }


/*std::string Lexer::ToString(int valueLength) {
    std::ostringstream returnType;
    returnType << "(" << TypeToString(itemType) << ",\"" << tokenValue.substr(0, valueLength) << "\"," << tokenLine
               << ")";
    std::cout << returnType.str() << std::endl; // just a lil' test
    return returnType.str();
}*/